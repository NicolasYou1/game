from django.contrib import admin

from blogs.models import BlogPost

admin.site.register(BlogPost)